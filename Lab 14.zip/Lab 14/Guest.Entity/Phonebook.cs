﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guest.Entity
{
    [Serializable]
    public class Phonebook
    {
        int GuestId;
        string GuestName;
        Relation relationship;
        string ContactNumber;
        
       
        private int Guest;

        public int guest
        {
            get { return Guest; }
            set { Guest = value; }
        }

        public int GuestId1 { get { return GuestId; } set { GuestId = value; } }
        public string GuestName1 { get { return GuestName; } set { GuestName = value; } }
       public  Relation Relationship { get {return relationship; } set{ relationship = value; } }
        public string ContactNumber1 { get { return ContactNumber; } set { ContactNumber = value; } }
    }
    public enum Relation
    {
        Father,
        Mother,
        Brother,
        Sister,
        Cousin,
        Uncle,
        Aunt,
        Son,
        Daughter,
        Friend,

    }
}

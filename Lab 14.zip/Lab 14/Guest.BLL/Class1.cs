﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Guest.Entity;
using Guest.DAL;
using Guest.Exception;
using System.Text.RegularExpressions;

namespace Guest.BLL
{
    public class Class1
    {
        static List<Phonebook> phoneList = new List<Phonebook>();
        public static bool AddGuest(Phonebook p)
        {
            bool guestAdded = false;
            try
            {
                if (ValidateGuest(p))
                {
                    guestAdded = Operations.AddGuest(p);
                }
                else
                {
                    throw new PhoneBookException("Contact Details Are Invalid!");
                }
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestAdded;
        }
        public static List<Phonebook> ListAllGuests()
        {
            List<Phonebook> phoneList = null;
            try
            {
                phoneList = Operations.ListAllGuests();
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return phoneList;
        }
        public static Phonebook SearchGuestById(int GuestId)
        {
            Phonebook p = null;
            try
            {
                p = Operations.SearchGuestById(GuestId);
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return p;
        }
        public static Phonebook SearchGuestByRelationship(Relation relationship)
        {
            Phonebook p = null;
            try
            {
                p = Operations.SearchGuestByRelationship(relationship);
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return p;
        }
        public static bool UpdateGuest(Phonebook p)
        {
            bool guestUpdated = false;
            try
            {
                  guestUpdated = Operations.UpdateGuest(p);
                
                
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestUpdated;
        }
        public static bool DeleteGuest(int GuestId)
        {
            bool GuestDeleted = false;
            try
            {
                GuestDeleted = Operations.DeleteGuest(GuestId);
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return GuestDeleted;
        }
        public static bool ValidateGuest(Phonebook p)
        {
            bool guestValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                if (p.GuestId1 < 100000 || p.GuestId1> 999999)
                {
                    message.Append("Guest ID Should Be A 6 Digit Number\n");
                    guestValidated = false;
                }
                if (!Regex.IsMatch(p.GuestName1, "[A-Z][a-z]+"))
                {
                    message.Append("Guest Name Should Start With Capital Alphabet And It Should Have Alphabets Only\n");
                    guestValidated = false;
                }
                
                if (!Regex.IsMatch(p.ContactNumber1, "^[789][0-9]{9}$"))
                {
                    message.Append("Phone Number Should Start With 7, 8 Or 9 And Should Have 10 Digits Only\n");
                    guestValidated = false;
                }
                if (guestValidated == false)
                {
                    throw new PhoneBookException(message.ToString());
                }
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestValidated;
        }

    }
}

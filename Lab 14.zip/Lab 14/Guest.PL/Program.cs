﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Guest.Entity;
using Guest.Exception;
using Guest.BLL;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Guest.PL
{
    class Program
    {
        public static void AddGuest()
        {
            Phonebook p = new Phonebook();
            try
            {
                Console.WriteLine("Enter Guest ID:");
                p.GuestId1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Guest Name:");
                p.GuestName1= Console.ReadLine();
                Console.WriteLine("Enter Guest phone number:");
                p.ContactNumber1 = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your Relationship choice:\n1.Father\n 2.Mother \n 3.Brother\n4.Sister\n5.Cousin\n6.uncle\n7.Aunt\n8.Son\n9.Daughter\n10.Friend");
                int relchoice = Convert.ToInt32(Console.ReadLine());
                switch (relchoice)
                {
                    case 1:
                        p.Relationship = Relation.Father;
                        break;
                    case 2:
                        p.Relationship = Relation.Mother;
                        break;
                    case 3:
                        p.Relationship = Relation.Brother;
                        break;
                    case 4:
                        p.Relationship = Relation.Sister;
                        break;
                    case 5:
                        p.Relationship = Relation.Cousin;
                        break;
                    case 6:
                        p.Relationship = Relation.Uncle;
                        break;
                    case 7:
                        p.Relationship = Relation.Aunt;
                        break;
                    case 8:
                        p.Relationship = Relation.Son;
                        break;
                    case 9:
                        p.Relationship = Relation.Daughter;
                        break;
                    case 10:
                        p.Relationship = Relation.Friend;
                        break;
                    default:
                        Console.WriteLine("Please Make A Valid Choice!");
                        break;
                        
                }
                

                bool guestAdded = Class1.AddGuest(p);
                if (guestAdded)
                {
                    
                    Console.WriteLine("Guest Added Successfully");
                }
                else
                {
                    throw new PhoneBookException("Guest Not Added!");
                }
            }
            catch (PhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            DeserialData();


        }

        public static void UpdateGuest()
        {
         Phonebook p = new Phonebook();
            try
            {
                Console.WriteLine("Enter Guest ID whose details are to be updated:");
                p.GuestId1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Guest Name:");
            p.GuestName1 = Console.ReadLine();
                //Console.WriteLine("Enter Guest relationship:");
                //p.Relationship = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Phone Number:");
                p.ContactNumber1 = Console.ReadLine();

                bool guestUpdated = Class1.UpdateGuest(p);
                if (guestUpdated == true)
                {
                    Console.WriteLine("Guest Details Updated Successfully");
                }
                else
                {
                    throw new PhoneBookException("Guest Not Updated!");
                }
            }
            catch (PhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            DeserializeData();

        }

        public static void DeleteGuest()
        {
            int GuestId1;
            try
            {
                Console.WriteLine("Enter guest ID whose details are to be deleted:");
               GuestId1 = Convert.ToInt32(Console.ReadLine());

                bool guestDeleted = Class1.DeleteGuest(GuestId1);
                if (guestDeleted)
                {
                    Console.WriteLine("Guests Details Deleted Successfully");
                }
                else
                {
                    throw new PhoneBookException("Guest Details Not Deleted");
                }
            }
            catch (PhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            DeserialData();
        }

        public static void SearchGuestById()
        {
            int GuestId1;
            try
            {
                Console.WriteLine("Enter Guest ID whose details are to be Searched:");
                GuestId1 = Convert.ToInt32(Console.ReadLine());

                Phonebook p = Class1.SearchGuestById(GuestId1);
                if (p != null)
                {
                    Console.WriteLine("Guest ID:" + p.GuestId1);
                    Console.WriteLine("Guest Name:" + p.GuestName1);
                    Console.WriteLine("Guest relationship:" + p.Relationship);
                    
                    Console.WriteLine("Guest phone number:" + p.ContactNumber1);
                }
                else
                {
                    throw new PhoneBookException("Guest Details Not Found");
                }
            }
            catch (PhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            DeserialData();
        }
        public static void SearchGuestByRelationship()
        {
            Phonebook p = new Phonebook();
            int choice;
            try
            {
                Console.WriteLine("Enter Guest relationship whose details are to be Searched:\n1.Father\n2.Mother\n3.Brother\n4.sister\n5.Cousin\n6.aunt\n7.Uncle\n8.Son\n9.Daughter\n10.Friend");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        p.Relationship = Relation.Father;
                        break;
                    case 2:
                        p.Relationship = Relation.Mother;
                        break;
                    case 3:
                        p.Relationship = Relation.Brother;
                        break;
                    case 4:
                        p.Relationship = Relation.Sister;
                        break;
                    case 5:
                        p.Relationship = Relation.Cousin;
                        break;
                    case 6:
                        p.Relationship = Relation.Uncle;
                        break;
                    case 7:
                        p.Relationship = Relation.Aunt;
                        break;
                    case 8:
                        p.Relationship = Relation.Son;
                        break;

                    case 9:
                        p.Relationship = Relation.Daughter;
                        break;
                    case 10:
                        p.Relationship = Relation.Friend;
                        break;
                    default:
                        Console.WriteLine("Please Make A Valid Choice!");
                        break;

                }

                Class1.SearchGuestByRelationship(p.Relationship);
                if (p != null)
                {
                    Console.WriteLine("Guest ID:" + p.GuestId1);
                    Console.WriteLine("Guest Name:" + p.GuestName1);
                    Console.WriteLine("Guest relationship:" + p.Relationship);

                    Console.WriteLine("Guest phone number:" + p.ContactNumber1);
                }
                else
                {
                    throw new PhoneBookException("Guest Details Not Found");
                }

            }
            catch (PhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            DeserialData();
        }

        public static void ListAllGuests()
        {
            List<Phonebook>phoneList = null;
            try
            {
                phoneList = Class1.ListAllGuests();
                if (phoneList.Count > 0)
                {
                    foreach (Phonebook p in phoneList)
                    {
                        Console.WriteLine("****************************************");
                        Console.WriteLine("GuestID \t GuestName \t Phone \tRelationship");
                        Console.WriteLine("****************************************");
                       
                        Console.WriteLine(p.GuestId1 + "\t" + p.GuestName1 + "\t" + p.ContactNumber1 +"\t" +p.Relationship);
                        SerializeData(p);
                        
                    }
                }
                else
                {
                    throw new PhoneBookException("Guests Are Not Available!");
                }
            }
            catch (PhoneBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            DeserialData();

        }

        private static void DeserialData()
        {
            Phonebook p1 = DeserializeData();
            Console.WriteLine("Deserialized data:");
            Console.WriteLine("Guest Id:" + p1.GuestId1);
            Console.WriteLine("Guest Name:" + p1.GuestName1);
            Console.WriteLine("Guest Contact:" + p1.ContactNumber1);
        }
        private static void SerializeData(Phonebook p)
        {
            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fileStream, p);
            fileStream.Close();
        }


        private static Phonebook DeserializeData()
        {
            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            Phonebook p1 = (Phonebook)binaryFormatter.Deserialize(fileStream);
            fileStream.Close();

            return p1;
        }


        static void Main(string[] args)
        {
          
            int choice;
            do
            {
                Console.WriteLine("Enter Choice:");
                Console.WriteLine("1. Add Guest");
                Console.WriteLine("2. UpdateGuest");
                Console.WriteLine("3. DeleteGuest");
                Console.WriteLine("4. SearchGuestById");
                Console.WriteLine("5. ListAllGuests");
                Console.WriteLine("6. Search Guest By Relationship");
                Console.WriteLine("7.Exit");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        UpdateGuest();
                        break;
                    case 3:
                        DeleteGuest();
                        break;
                    case 4:
                        SearchGuestById();
                        break;
                    case 5:
                        ListAllGuests();
                        break;
                    case 6:
                        SearchGuestByRelationship();
                        break;
                    case 7:
                        
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Please Make A Valid Choice!");
                        break;
                }
            }
            while (choice != 7);
            Console.ReadKey();
        }
    }
    }


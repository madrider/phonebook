﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Guest.Entity;
using Guest.Exception;



namespace Guest.DAL
{
    public class Operations
    {

        static List<Phonebook> phoneList = new List<Phonebook>();

        //Function To Add New guest In Collection
        public static bool AddGuest(Phonebook p)
        {
            bool guestAdded = false;
            try
            {
                //Adding guest
                phoneList.Add(p);
                guestAdded = true;
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestAdded;
        }
        public static List<Phonebook> ListAllGuests()
        {
            
            return phoneList;
        }
        
        public static Phonebook SearchGuestById(int Id)
        {
           Phonebook p= null;
            try
            {
                //Searching guest
                p =phoneList.Find(e => e.GuestId1 == Id);
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return p;
        }
        public static Phonebook SearchGuestByRelationship(Relation relationship1)
        {
            Phonebook p = null;
            try
            {
                p = phoneList.Find(e => e.Relationship == relationship1);
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return p;
        }
        public static bool UpdateGuest(Phonebook p)
        {
            bool GuestUpdated = false;

            try
            {
                for (int i = 0; i < phoneList.Count; i++)
                {
                    if (phoneList[i].GuestId1 == p.GuestId1)
                    {
                        phoneList[i].GuestName1 = p.GuestName1;
                        

                        phoneList[i].ContactNumber1 = p.ContactNumber1;
                        GuestUpdated = true;

                    }
                }
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return GuestUpdated;
        }
        public static bool DeleteGuest(int GuestId)
        {
            bool GuestDeleted = false;
            try
            {
                //Searching Employee
               Phonebook p = phoneList.Find(e => e.GuestId1 == GuestId);
                if (p != null)
                {
                    //Deleting Employee
                    phoneList.Remove(p);
                    GuestDeleted = true;
                }
                else
                {
                    throw new PhoneBookException("Guest Id" + GuestId + " does not Exist!");
                }
            }
            catch (PhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return GuestDeleted;
        }
    }
}

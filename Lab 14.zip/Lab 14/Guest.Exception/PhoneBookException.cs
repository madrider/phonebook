﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guest.Exception
{
    public class PhoneBookException:ApplicationException
    {

        public PhoneBookException()
            : base()
        {
           
        }
        public PhoneBookException(string message)
            : base(message)
        {

        }
        public PhoneBookException(string message,System.Exception innerException)
            :base(message,innerException)
        {

        }
    }
}
